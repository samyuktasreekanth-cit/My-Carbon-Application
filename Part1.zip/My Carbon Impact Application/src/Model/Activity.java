package Model;

import java.io.Serializable;

public class Activity implements Serializable {

    private int week ;
    private String date;
    private String activity;
    private int points;

    public Activity(int week_spinner, String datebox, String activityInput, int points_spinner) {
        this.week = week_spinner;
        this.date = datebox;
        this.activity = activityInput;
        this.points = points_spinner;
    }

    //getter
    public String getActivity() {
        return activity;
    }

    public int getPoints() {
        return points;
    }

    public int getWeek() {
        return week;
    }

    public String getDate() {
        return date;
    }

    //setter

    public void setDate(String date) {
        this.date = date;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public void setWeek(int week) {
        this.week = week;
    }

    @Override
    public String toString() {
        return "week= " + week +
                ", date= " + date +
                ", activity= '" + activity + '\'' +
                ", points= " + points + "\n";
    }

//    public void print(){
//        System.out.println(week + date + activity + points);
//    }
}
