package View;

import Model.Activity;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.TilePane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.control.TextArea;

import java.io.*;
import java.util.ArrayList;

public class MyMain extends Application {

    private Label DateLabel;
    private TextArea activity_display;
    private ArrayList<Activity> activity_list;

    @Override
    public void start(Stage stage) throws Exception {

        stage.setTitle("My Carbon Awareness Effect");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));

        //week
        Label WeekLabel = new Label("Week _ _ _ _ _ _ _ _");
        GridPane.setConstraints(WeekLabel, 0, 0);

        TextField week_spinner = new TextField("3");
        GridPane.setConstraints(week_spinner, 1, 0);

        //Date
        DateLabel = new Label("Date _ _ _ _ _ _ _ _");
        GridPane.setConstraints(DateLabel, 0, 1);

        DatePicker datebox = new DatePicker();
        GridPane.setConstraints(datebox, 1, 1);

        //ActivityLabel
        Label ActivityLabel = new Label("Activity _ _ _ _ _ _ _ _");
        GridPane.setConstraints(ActivityLabel, 0, 2);

        TextField ActivityInput = new TextField();
        GridPane.setConstraints(ActivityInput, 1, 2);

        //Points
        Label PointsLabel = new Label("points-10-- +10 _ _ _ _ _ _ _ _");
        GridPane.setConstraints(PointsLabel, 0, 3);

        //points spinner
        //Spinner<Integer> points_spinner = new Spinner<>(-10, 10, 1);
        TextField points_spinner = new TextField("3");
        GridPane.setConstraints(points_spinner, 1, 3);

        //add button
        Button add_button = new Button("Add");
        add_button.setLayoutX(10);
        add_button.setLayoutY(120);

        activity_display = new TextArea("Activities to be displayed");
        activity_display.setLayoutX(10);
        activity_display.setLayoutY(150);

        activity_list = new ArrayList<Activity>();

        add_button.setOnAction(e -> {
            Activity activityObject = new Activity(Integer.parseInt(week_spinner.getText()), datebox.getValue().toString(), ActivityInput.getText(), Integer.parseInt(points_spinner.getText()));
            activity_list.add(activityObject);
            String display = "";
            for (Activity i : activity_list) {
                display += i.toString() + "\n";
            }
            activity_display.setText(display);
        });

        //remove button
        Button remove_button = new Button("Remove");
        remove_button.setLayoutX(60);
        remove_button.setLayoutY(120);

        ArrayList<String> choices = new ArrayList<>();

        remove_button.setOnAction(e -> {
            choices.clear();
            for (Activity i : activity_list) {
                choices.add(i.getActivity());
            }
            ChoiceDialog<String> rem_diag = new ChoiceDialog<String>("None", choices);
            rem_diag.setTitle("Remove");
            rem_diag.setHeaderText("Choose an activity to remove: ");
            rem_diag.showAndWait();

            String after_rem_display = "";
            for (int i = 0; i < activity_list.size(); i++) {
                Activity activityloop = activity_list.get(i);
                if (activityloop.getActivity().equals(rem_diag.getSelectedItem())) {
                    activity_list.remove(i);
                    for (Activity j : activity_list) {
                        after_rem_display += j.toString() + "\n";
                    }
                } else {
                    continue;
                }
            }
            activity_display.setText(after_rem_display);
        });

        //list button
        Button list_button = new Button("List");
        list_button.setLayoutX(130);
        list_button.setLayoutY(120);

        list_button.setOnAction(e -> {

            String mini_list = "";
            for (Activity i : activity_list) {
                mini_list += i.getActivity() + "\t\t" + i.getPoints() + "\n";
            }

            Alert list_alert = new Alert(Alert.AlertType.INFORMATION);
            list_alert.setTitle("List");
            list_alert.setHeaderText(null);
            list_alert.setContentText("Activity\tPoints\n" + mini_list);
            list_alert.showAndWait();

        });

        //summary button
        Button summary_button = new Button("Summary");
        summary_button.setLayoutX(180);
        summary_button.setLayoutY(120);

        summary_button.setOnAction(e -> {
            int counter = 0;
            for (Activity i : activity_list) {
                counter += i.getPoints();
            }
            Alert summary_box = new Alert(Alert.AlertType.INFORMATION);
            summary_box.setTitle("Summary");
            summary_box.setHeaderText(null);
            summary_box.setContentText("Points: " + counter);
            summary_box.show();
        });

        //save button
        Button save_button = new Button("Save");

        save_button.setOnAction(e -> {
            try {
                FileOutputStream f_out = new FileOutputStream(new File("carbon.txt.txt"));
                ObjectOutputStream o_out = new ObjectOutputStream(f_out);

                o_out.writeObject(activity_list);

                activity_display.setText("Saved to file");
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });

        //load button
        Button load_button = new Button("Load");

        load_button.setOnAction(e -> {
            try {

                FileInputStream f_in = new FileInputStream(new File("carbon.txt.txt"));
                ObjectInputStream o_in = new ObjectInputStream(f_in);

                activity_list = (ArrayList<Activity>) o_in.readObject();
                String load = "";
                for (int i = 0; i < activity_list.size(); i++) {
                    Activity load_activity = activity_list.get(i);
                    load += load_activity;
                }
                activity_display.setText(load);

            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            } catch (IOException ex) {
                ex.printStackTrace();
            } catch (ClassNotFoundException ex) {
                ex.printStackTrace();
            } catch (ClassCastException ex) {
                System.out.println("Class not found\njava.lang.ClassCastException: class java.lang.String cannot be cast to class java.util.ArrayList");
                //ex.printStackTrace();
                return;
            }
        });

        //exit button
        Button exit_button = new Button("Exit");
        exit_button.setOnAction(e -> {
            Platform.exit();
        });

        TilePane tp = new TilePane();
        tp.getChildren().add(save_button);
        tp.getChildren().add(load_button);
        tp.getChildren().add(exit_button);
        tp.setHgap(10);
        tp.setLayoutX(10);
        tp.setLayoutY(340);

        grid.getChildren().addAll(WeekLabel, DateLabel, ActivityLabel, PointsLabel, week_spinner, datebox, ActivityInput, points_spinner);

        Group root = new Group(grid, add_button, remove_button, list_button, summary_button, activity_display, tp);

        Scene scene = new Scene(root, 750, 400);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}


//create a method for the arraylist
//put the exit farther away
