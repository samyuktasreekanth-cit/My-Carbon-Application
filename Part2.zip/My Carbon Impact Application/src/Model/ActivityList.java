//package Model;
//public class ActivityList {
//    //attributes
//    private String activity_name;
//    private int points;
//
//    //constructor
//    public ActivityList(String activity_name, int points){
//        this.activity_name = activity_name;
//        this.points = points;
//    }
//
//    //getter
//    public String getActivity_name() {
//        return activity_name;
//    }
//
//    public int getPoints() {
//        return points;
//    }
//
//    //setter
//    public void setActivity_name(String activity_name) {
//        this.activity_name = activity_name;
//    }
//    public void setPoints(int points) {
//        this.points = points;
//    }
//
//    @Override
//    public String toString() {
//        return activity_name + '\t' + points ;
//    }
//}
