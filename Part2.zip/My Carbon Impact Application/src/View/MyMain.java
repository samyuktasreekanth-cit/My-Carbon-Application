package View;

import Model.Activity;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.control.TextArea;

import java.util.Comparator;

import java.io.*;
import java.util.*;

public class MyMain extends Application {

    private Label DateLabel;
    private TextArea activity_display;
    private ArrayList<Activity> activity_list;
    private Button drop_down_activity;
    private TextField ActivityDropShow;
    private ChoiceDialog<String> act_diag;
    private String chosen_activity;
    private int chosen_points;
    private ArrayList<String> list_of_activities;
    private ComboBox combobox;
    private ChoiceDialog<String> rem_diag;

    private ObservableList<String> options;


    @Override
    public void start(Stage stage) throws Exception {

        stage.setTitle("My Carbon Awareness Effect");

        GridPane grid = new GridPane();

        grid.setPadding(new Insets(10, 10, 10, 10));

        //week
        Label WeekLabel = new Label("Week _ _ _ _ _ _ _ _");
        grid.setConstraints(WeekLabel, 0, 0);

        TextField week_spinner = new TextField("3");
        grid.setConstraints(week_spinner, 1, 0);

        //Date
        DateLabel = new Label("Date _ _ _ _ _ _ _ _");
        grid.setConstraints(DateLabel, 0, 1);

        DatePicker datebox = new DatePicker();
        grid.setConstraints(datebox, 1, 1);

        //ActivityLabel
        Label ActivityLabel = new Label("Activity _ _ _ _ _ _ _ _");
        grid.setConstraints(ActivityLabel, 0, 2);

        //can type in new activity
        String activity_in_combobox[] =
                {"walking to work:10",
                        "Eating a 8oz steak:-10",
                        "Cycling to the shops:5",
                        "Driving to work:-5",
                        "Vegetarian for a day:7"};
        combobox = new ComboBox(FXCollections.observableArrayList(activity_in_combobox));


        //APP STUFF
        GridPane app_grid = new GridPane();
        Label app_label = new Label("Enter activity (activity:points)");
        app_grid.setConstraints(app_label, 0, 1);

        //text area for app
        TextField app_user_input = new TextField();
        app_grid.setConstraints(app_user_input, 0, 2);

        //Text area app
        TextArea app_text_area = new TextArea();
        app_grid.setConstraints(app_text_area, 0, 4);

        //add button for app
        Button add_app_button = new Button("Add");

        //array list of strings
        list_of_activities = new ArrayList<>();
        add_app_button.setOnAction(e -> {
            try (Scanner scanner = new Scanner(new File("app.txt"))) {
                //storing the contents of file to the arraylist
                while (scanner.hasNext()) {
                    list_of_activities.add(scanner.nextLine());
                }

                list_of_activities.add(app_user_input.getText());

                //updating the text file with the new added activity and points
                try {
                    //Saving of object in a file
                    FileOutputStream file = new FileOutputStream("app.txt");
                    ObjectOutputStream out = new ObjectOutputStream(file);
                    // Method for serialization of object
                    out.writeObject(list_of_activities);
                    out.close();
                    file.close();
                    System.out.println("saved to file");
                } catch (IOException ex) {
                    System.out.println("cannot save to file");
                }

                //print the updated txt file to the text area in the app
                try {
                    ObjectInputStream is = new ObjectInputStream(new FileInputStream("app.txt"));
                    list_of_activities = (ArrayList<String>) is.readObject();
                    String loading_from_txt = "";
                    for (String l : list_of_activities) {
                        loading_from_txt += l + "\n";
                    }
                    app_text_area.setText(loading_from_txt);
                    is.close();
                } catch (Exception ex) {
                    System.out.println("could not load");
                    ex.printStackTrace();
                }
                //diplaying arraylist to the app text area
                System.out.println(list_of_activities);
            } catch (FileNotFoundException a) {
                a.printStackTrace();
            }
        });

        //END OF APP STUFF
        grid.setConstraints(combobox, 1, 2);

        //add button
        Button add_button = new Button("Add");
        add_button.setLayoutX(10);
        add_button.setLayoutY(120);

        activity_display = new TextArea("Activities to be displayed");
        activity_display.setLayoutX(10);
        activity_display.setLayoutY(150);

        activity_list = new ArrayList<Activity>();

        add_button.setOnAction(e -> {
            String myString = (String) combobox.getValue();
            String activity_from_dropdown = myString.split(":")[0];
            String points_from_dropdown = myString.split(":")[1];

            Activity activityObject = new Activity(Integer.parseInt(week_spinner.getText()), datebox.getValue().toString(), activity_from_dropdown, Integer.parseInt(points_from_dropdown));
            activity_list.add(activityObject);
            String display = "";
            for (Activity i : activity_list) {
                display += i.toString() + "\n";
            }
            activity_display.setText(display);
        });

        //remove button
        Button remove_button = new Button("Remove");
        remove_button.setLayoutX(60);
        remove_button.setLayoutY(120);

        ArrayList<String> choices = new ArrayList<>();

        remove_button.setOnAction(e -> {
            choices.clear();
            for (Activity i : activity_list) {
                choices.add(i.getActivity());
            }
            ChoiceDialog<String> rem_diag = new ChoiceDialog<String>("None", choices);
            rem_diag.setTitle("Remove");
            rem_diag.setHeaderText("Choose an activity to remove: ");
            rem_diag.showAndWait();

            String after_rem_display = "";
            for (int i = 0; i < activity_list.size(); i++) {
                Activity activityloop = activity_list.get(i);
                if (activityloop.getActivity().equals(rem_diag.getSelectedItem())) {
                    activity_list.remove(i);
                    for (Activity j : activity_list) {
                        after_rem_display += j.toString() + "\n";
                    }
                } else {
                    continue;
                }
            }
            activity_display.setText(after_rem_display);
        });

        //list button
        Button list_button = new Button("List");
        list_button.setLayoutX(130);
        list_button.setLayoutY(120);

        list_button.setOnAction(e -> {

            String mini_list = "";
            for (Activity i : activity_list) {
                mini_list += i.getActivity() + "\t\t" + i.getPoints() + "\n";
            }

            Alert list_alert = new Alert(Alert.AlertType.INFORMATION);
            list_alert.setTitle("List");
            list_alert.setHeaderText(null);
            list_alert.setContentText("Activity\tPoints\n" + mini_list);
            list_alert.showAndWait();

        });

        //summary button
        Button summary_button = new Button("Summary");
        summary_button.setLayoutX(180);
        summary_button.setLayoutY(120);

        summary_button.setOnAction(e -> {
            int counter = 0;
            for (Activity i : activity_list) {
                counter += i.getPoints();
            }
            Alert summary_box = new Alert(Alert.AlertType.INFORMATION);
            summary_box.setTitle("Summary");
            summary_box.setHeaderText(null);
            summary_box.setContentText("Points: " + counter);
            summary_box.show();
        });

        //save button
        Button save_button = new Button("Save");

        save_button.setOnAction(e -> {
            try {
                FileOutputStream f_out = new FileOutputStream(new File("carbon.txt.txt"));
                ObjectOutputStream o_out = new ObjectOutputStream(f_out);

                o_out.writeObject(activity_list);

                activity_display.setText("Saved to file");
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });

        //load button
        Button load_button = new Button("Load");

        load_button.setOnAction(e -> {
            try {
                FileInputStream f_in = new FileInputStream(new File("carbon.txt.txt"));
                ObjectInputStream o_in = new ObjectInputStream(f_in);

                activity_list = (ArrayList<Activity>) o_in.readObject();
                String load = "";
                for (int i = 0; i < activity_list.size(); i++) {
                    Activity load_activity = activity_list.get(i);
                    load += load_activity;
                }
                activity_display.setText(load);

            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            } catch (IOException ex) {
                ex.printStackTrace();
            } catch (ClassNotFoundException ex) {
                ex.printStackTrace();
            } catch (ClassCastException ex) {
                System.out.println("Class not found\njava.lang.ClassCastException: class java.lang.String cannot be cast to class java.util.ArrayList");
                //ex.printStackTrace();
                return;
            }
        });

        //exit button
        Button exit_button = new Button("Exit");
        exit_button.setOnAction(e -> {
            Platform.exit();
        });

        //tile pane for load, save and exit
        TilePane tp = new TilePane();
        TilePane tp_e = new TilePane();
        tp.getChildren().add(save_button);
        tp.getChildren().add(load_button);
        tp_e.getChildren().add(exit_button);
        tp.setHgap(10);
        tp.setLayoutX(10);
        tp.setLayoutY(340);
        tp_e.setLayoutX(450);
        tp_e.setLayoutY(340);

        //RESULT TAB content stuff
        Button order_by_date = new Button("ORDER BY DATE");
        Button order_by_activity = new Button("ORDER BY ACTIVITY");

        HBox result_order_buttons = new HBox(order_by_date, order_by_activity);

        TextArea results_text_area = new TextArea("Results to be displayed");
        results_text_area.setLayoutX(10);
        results_text_area.setLayoutY(60);

        //order by date button
        order_by_date.setOnAction(e -> {
            Collections.sort(activity_list, new Comparator<Activity>() {
                @Override
                public int compare(Activity a1, Activity a2) {
                    return String.valueOf(a1.getDate()).compareTo(a2.getDate());
                }
            });
            String order_date_display = "";
            for (int i = 0; i < activity_list.size(); i++) {
                //System.out.println(activity_list.get(i).getDate());
                order_date_display += activity_list.get(i).getDate() + "\t" + activity_list.get(i).getActivity() + "\t" + activity_list.get(i).getPoints() + "\n";
            }
            results_text_area.setText(order_date_display);
        });

        //order by activity button
        order_by_activity.setOnAction(e -> {
            Collections.sort(activity_list, new Comparator<Activity>() {
                @Override
                public int compare(Activity a1, Activity a2) {
                    return String.valueOf(a1.getActivity()).compareTo(a2.getActivity());
                }
            });
            String order_activity_display = "";
            for (int i = 0; i < activity_list.size(); i++) {
                //System.out.println(activity_list.get(i).getDate());
                order_activity_display += activity_list.get(i).getDate() + "\t" + activity_list.get(i).getActivity() + "\t" + activity_list.get(i).getPoints() + "\n";
            }
            results_text_area.setText(order_activity_display);
        });

        // INTRO STUFF
        Label intro_label = new Label("Welcome To Your\nMy Carbon Impact Application");
        StackPane sp = new StackPane();
        sp.getChildren().add(intro_label);

        //ACTIVITY MANAGEMENT STUFF
        grid.getChildren().addAll(WeekLabel, DateLabel, ActivityLabel, week_spinner, datebox, combobox);
        Group root = new Group(grid, add_button, remove_button, list_button, summary_button, activity_display, tp, tp_e);

        //RESULTS STUFF
        Group result_group = new Group(result_order_buttons, results_text_area);

        //APP STUFF CONTINUED

        //remove button for app
        Button remove_app_button = new Button("Remove App");
        ArrayList<String> app_choices = new ArrayList<String>();
        remove_app_button.setOnAction(e -> {
            app_choices.clear();
            try {
                // Reading the object from a file
                FileInputStream file = new FileInputStream("app.txt");
                ObjectInputStream in = new ObjectInputStream(file);

                // Method for deserialization of object
                ArrayList<String> object1 = (ArrayList<String>) in.readObject();

                in.close();
                file.close();

                rem_diag = new ChoiceDialog<String>("None", object1);
                rem_diag.setTitle("Remove");
                rem_diag.setHeaderText("Choose an activity to remove: ");
                rem_diag.showAndWait();

                String rem_act = rem_diag.getSelectedItem();

                for (String s : object1) {
                    if (s.equals(rem_act)) {
                        list_of_activities.remove(s);
                    }
                }

                //update the removed drop down list
                String updated = "";
                for (String g : list_of_activities) {
                    updated += g + "\n";
                }

                app_text_area.setText(updated);
                //save it to the list
                try {
                    FileOutputStream f_out = new FileOutputStream(new File("app.txt"));
                    ObjectOutputStream o_out = new ObjectOutputStream(f_out);

                    o_out.writeObject(list_of_activities);

                } catch (FileNotFoundException ex) {
                    ex.printStackTrace();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }

            } catch (IOException ex) {
                System.out.println("IOException is caught");
            } catch (ClassNotFoundException ex) {
                System.out.println("ClassNotFoundException is caught");
            }
        });

        HBox app_button_hbox = new HBox(add_app_button, remove_app_button);
        app_grid.setConstraints(app_button_hbox, 0, 3);

        app_grid.getChildren().addAll(app_label, app_user_input, app_button_hbox, app_text_area);

        Group app_group = new Group(app_grid);

        StackPane app_stack = new StackPane(app_group);

        //ref for syntax: http://tutorials.jenkov.com/javafx/tabpane.html
        TabPane tabpane = new TabPane();
        Tab intro_tab = new Tab("Intro", sp);
        Tab act_man_tab = new Tab("Activity Management", root);
        Tab results_tab = new Tab("Results", result_group);
        Tab app_tab = new Tab("App", app_stack);
        tabpane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        tabpane.getTabs().add(intro_tab);
        tabpane.getTabs().add(act_man_tab);
        tabpane.getTabs().add(results_tab);
        tabpane.getTabs().add(app_tab);
        tabpane.setPrefSize(700, 100);

        Scene scene = new Scene(tabpane, 750, 400);
        stage.setScene(scene);
        stage.show();
    }

    //putting in methods
    ArrayList loadList(ArrayList list_of_activities) {
        return list_of_activities;
    }

    public static void main(String[] args) {
        launch(args);
    }
}


//things to do:
//put the app in the main activity after mvc
//error checking
//mvc - part 3


//walking to work:10"
//Eating a 8oz steak:-10"
//Cycling to the shops:5"
//Driving to work:-5"
//Vegetarian for a day:7

//�� sr java.util.ArrayListx����a� I sizexp   w   t walking to work:10"t Eating a 8oz steak:-10"t Cycling to the shops:5"t Driving to work:-5"t Vegetarian for a day:7t aff:9x
